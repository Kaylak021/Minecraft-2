# -- Class do Player conhecido como Jogador que possui todas coisas basicas nela --

class Jogador():
    def __init__(self):
        self.nome = ""
        
        self.atk = 5

        self.hp = 20
        self.pntcura = 2

    def inserirNome(self, nome:str):
        self.nome = nome

    def definirArma(self, atk:int):
        self.atk = atk

    def atacar(self, Monstro):
        Monstro.hp -= self.atk

    def curar(self):
        self.hp += self.pntcura

        if self.hp > 20:
            self.hp = 20
            print(f"\nImpossivel se curar: HP já está cheio!\n")

        else:
            return print(f"\n{self.nome} curou {self.pntcura} pontos de vida! \nVida Atual: HP: {self.hp}\n")
        
         

# -- Classe dos inimigos do joguinho --

class Monstro():
    def __init__(self, nome, hp, atk):
        self.nome = nome
        self.hp = hp
        self.atk = atk

    def definirNome(self, nome):
        self.nome = nome

    def definirAtaque(self, atk):
        self.atk = atk

    def definirHp(self, hp):
        self.hp = hp

    def atacarJogador(self, Jogador):
        Jogador.hp -= self.atk