from Entidade import Jogador , Monstro
import Utilidades as u
# -- Aqui onde criamos os Objetos como: Jogodar e Monstro // Futuramente Armas e Armaduras // --
jogador = Jogador() 

jogador.inserirNome("Kay")

monstro = Monstro("Esqueleto", 20, 2)

# -- Aqui onde o Jogo começa a criar corpo de verdade --
u.iniciarMenu("Jogar", "Opções", "Creditos","Sair do Jogo")
entrada_menu = u.validarEntrada(1, 4)

if entrada_menu == 4:
    exit()

if entrada_menu == 1:
    u.iniciarEventoBatalha(jogador, monstro)

if entrada_menu == 2:
    print(f"Função ainda não liberada!")

if entrada_menu == 3:
    print(f"Opção ainda nao desbloqueada")