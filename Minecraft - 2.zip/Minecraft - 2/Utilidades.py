import time as t
import Entidade as e

# -- Criar menu do jeito que eu quero --
def iniciarMenu(*opcoes:str):  
    print("\nMinecraft 2 - O começo\n")

    print("Selecione uma das Opções abaixo para avançar!")

    for i, opcao in enumerate(opcoes, start=1):
        print(f"{i}. {opcao}")

# -- Criar um menu para selecionar oq o player ira fazer dentro de um evento max de opc --
def menuEvento(*opcoes:str):      
    print("Selecione uma das Opções abaixo para avançar!")
    t.sleep(0.3)

    for i, opcao in enumerate(opcoes, start=1):
        t.sleep(0.2)
        print(f"{i}. {opcao}")

# -- Criar um validador de entrada ex: input = 300 | exit = Valor incorreto --
def validarEntrada(min:int, max:int):
    while True:
        entrada = input("Insira uma das opções solicitadas: ").strip() # -- O .strip() faz com que dando ENTER vazio ele não bugue --

        if not entrada.isdigit(): # -- ele valida se e um digito --
            print("Digite apenas Números!")
            continue # -- se for ele continua --

        entrada = int(entrada) # -- depois de comparar ele setta pra ser um (int) --

        if min <= entrada <= max: # -- Aqui faz a compararção se esta dentro do minimo e maximo proposto --
            return entrada

        else:
            print("Valor inserido não está dentro do intervalo desejado!")

# -- Menu ~ Inciar ~ Aqui onde vamos iniciar a aventura: Lutas, Looting e Dialogos --
def iniciarEventoBatalha(jogador:object, monstro:object): # -- Aqui onde ele ira iniciar o modo de combate -- FUTURAMENTE EVOLUIR PARA UMA CLASS --
    print(f"\nEnquanto você andava pela floresta você encontrou um: {monstro.nome}\n")

    while (jogador.hp != 0 and monstro.hp != 0):
        
        menuEvento("Atacar", "Curar", "Fugir")
        entrada = validarEntrada(1, 3)  # -- Input do Usuario sobre as Opções acima --

        if entrada == 1:

            jogador.atacar(monstro)
            print(f"\n{jogador.nome}, atacou o {monstro.nome}, causando {jogador.atk} pontos de Dano!\n")
            t.sleep(0.8)    # -- Apos o User escolher (Atacar) ele ira rodar esse pedaço e comparar abaixo --

            if monstro.hp <= 0:
                monstro.hp = 0
                print(f"\nO {monstro.nome} foi derrotado!\n") # -- Aqui se retornar um valor negativo ele seta pra 0 e printa a mensagem de morte --
                break

            monstro.atacarJogador(jogador)
            print(f"O Jogador recebeu {monstro.atk} pontos de dano!\n")
            t.sleep(0.8)  # -- Apos o jogador atacar ira rodar esse codigo para o monstro atacar --

            if jogador.hp <= 0:
                jogador.hp = 0
                print(f"Você morreu!") # -- ja aqui e ao contrario, caso o jogador chegue em valores de HP negativo--
                break

            print(f"Vida atual de {jogador.nome}: HP {jogador.hp}\nVida atual do {monstro.nome}: HP {monstro.hp}\n")

        if entrada == 2:
        # -- Ideia de colocar Tipo de Poções de Cura -- 
            jogador.curar()

        if entrada == 3:
            print(f"fugiu")
            break

